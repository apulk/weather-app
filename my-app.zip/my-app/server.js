const express = require('express');
const bodyParser = require('body-parser');
const cors = require("cors");

// IMPORT MODELS
// require('./models/Product');

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

//Allow Cors
app.use(function(req, res, next) {
  // Website you wish to allow to connect
  res.setHeader("Access-Control-Allow-Origin", "*");

  // Request methods you wish to allow
  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET, POST, OPTIONS, PUT, PATCH, DELETE"
  );

  // Request headers you wish to allow
  res.setHeader(
    "Access-Control-Allow-Headers",
    "X-Requested-With,content-type"
  );

  // Set to true if you need the website to include cookies in the requests sent
  // to the API (e.g. in case you use sessions)
  res.setHeader("Access-Control-Allow-Credentials", true);

  // Pass to next layer of middleware
  // res.header("Access-Control-Allow-Origin", "http://localhost:3000");
  // res.header("Access-Control-Allow-Credentials",true);
  // res.header("Access-Control-Allow-Methods","GET, POST, OPTIONS")
  // res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

app.use(cors());


if (process.env.NODE_ENV === 'production') {
  app.use(express.static('theme/build'));

  const path = require('path');
  app.get('*', (req,res) => {
      res.sendFile(path.resolve(__dirname, 'theme', 'build', 'index.html'))
  })

}

var OAuth = require('oauth');
var header = {
    "X-Yahoo-App-Id": "a0a9Rl7i"
};
var request = new OAuth.OAuth(
    null,
    null,
    'dj0yJmk9MGFxeWo3WERpRWx6JmQ9WVdrOVlUQmhPVkpzTjJrbWNHbzlNQS0tJnM9Y29uc3VtZXJzZWNyZXQmc3Y9MCZ4PTMz',
    'b679d208370a778a5f0396c0992d9ae89ccc21a8',
    '1.0',
    null,
    'HMAC-SHA1',
    null,
    header
);
// request.get(
//     'https://weather-ydn-yql.media.yahoo.com/forecastrss?location=sunnyvale,ca&format=json',
//     null,
//     null,
//     function (err, data, result) {
//         if (err) {
//             console.log(err);
//         } else {
//             console.log(data)
//         }
//     }
// );

///Routes
app.post(`/upload`, async (req, res) => {
    // console.log(req.params)
    console.log(req.body)
    const result = req.body
    // return res.status(200).send({
    //             error: true,
    //             result
    //         })
    request.get(
        'https://weather-ydn-yql.media.yahoo.com/forecastrss?location='+result.data.city+'&format=json',
        null,
        null,
        function (err, data, result) {
            if (err) {
                console.log(err);
            } else {
                console.log(data)
                return res.json(data)
            }
        }
    );
     
  })


const PORT = process.env.PORT || 5001;
app.listen(PORT, () => {
  console.log(`app running on port ${PORT}`)
});
