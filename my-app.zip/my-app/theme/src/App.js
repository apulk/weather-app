import React, { Component,Suspense,lazy } from 'react'
import { Provider } from 'react-redux';
import store from './store';

const Weather = lazy(()=>import('./components/weather'))
export default class App extends Component {
  render() {
    return (
      <Provider  store={store}>
      <React.Fragment>
        <Suspense fallback={`Loading...`}>
          <Weather />
        </Suspense>
      </React.Fragment>
      </Provider>
    )
  }
}
