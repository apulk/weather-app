import React, { Component } from 'react'
import './index.css'
import Select from 'react-select';
import Axios from 'axios'
import $ from 'jquery'
import { baseUrl } from '../constant';
import store from '../store';
import { getAllCities } from '../actions';
import { connect } from 'react-redux';


class Weather extends Component {
    state = {
        selectedOption: '',
        weather:'',
        location:'',
        current_observation:'',
        city:''
    };
    handleChange = selectedOption => {
        this.setState({ selectedOption });
    };
    formSubmit = (e) => {
        e.preventDefault()
        $(".errShow").removeClass('d-block').addClass('d-none')
        if(this.state.selectedOption.value) {
            $(".btnSubmit").html('Loading...')
            this.setState({
                weather:''
            })
            var headers = {
                "Content-Type": "application/json"
            }
            var data = {
                "city": this.state.selectedOption.value,
                "label": this.state.selectedOption.label
            }
            Axios.post(
                `${baseUrl}/upload`,
                { data },
                {
                    headers
                }
            ).then(res => {
                const result = res.data;
                const weather = JSON.parse(result)
                this.setState({
                    weather
                })
                $(".btnSubmit").html('Show weather')
            });
        }
        else {
            $(".errShow").removeClass('d-none').addClass('d-block')
        }
    }
    componentDidMount(){
        store.dispatch(getAllCities())
    }
    render() {
        const { selectedOption } = this.state;
        const {location,current_observation} = this.state.weather
        return (
            <React.Fragment>
                <div className="form-signin">
                    <form className=" " onSubmit={this.formSubmit}>
                        <div className="text-center mb-4">
                            <img className="mb-4" src="/docs/4.4/assets/brand/bootstrap-solid.svg" alt="" width="72" height="72" />
                            <h1 className="h3 mb-3 font-weight-normal">Weather</h1>
                            <p><code>The forecast is beautiful</code> </p>
                        </div>
                        <div className="form-label-group">
                            <Select
                                value={selectedOption}
                                onChange={this.handleChange}
                                options={this.props.cities.data}
                                placeholder={'Select city'}
                            />
                        </div>

                        <button className="btn btn-primary btn-block btnSubmit" type="submit">
                            Show weather
                        </button>
                        <div className="form-label-group">
                            <div className="errShow d-none">
                                Please select a city.
                            </div>
                        </div>
                    </form>
                    {
                        this.state.weather &&
                    
                    <div className="container my-2">
                        <div className="row">
                            <div className="card col-12 p-0">
                                <div className="card-body">
                                    <h5 className="card-title">{location && location.city}</h5>
                                    <p className="card-text">{location && location.country}</p>
                                    <p className="card-text">{current_observation && current_observation.condition.temperature} F</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    }
                </div>
            </React.Fragment>
        )
    }
}
const mapStateToProps = state => ({ 
    cities:state.cities
  });
export default  connect( mapStateToProps)(Weather)
  